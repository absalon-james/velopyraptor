from distutils.core import setup

setup(
    name="Velopyraptor",
    version="0.2dev",
    packages=['velopyraptor',],
    license='Apache License, Version 2.0',
    long_description=open('README.txt').read()
)
